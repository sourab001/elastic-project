package com.mindtree.Indexing;

import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Map;

import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import au.com.bytecode.opencsv.CSVReader;

public class Indexing {

	@SuppressWarnings({ "unchecked", "resource" })
	public static void main(String[] args) throws IOException {
		System.out.println("WELCOME TO INDEXING...............!");

		/*CSVReader reader = new CSVReader(
				new FileReader("C://Users//M1049195//Desktop//ELK//elastic_main_project//data.csv"), '|');
*/CSVReader reader = new CSVReader(
		new FileReader("C://Users//M1049195//Desktop//ELK//elastic_main_project//Elasticsearch Project//wine_data.txt"), '|');
		TransportClient client;
		Settings settings = Settings.builder().put("cluster.name", "my-application").build();
		client = new PreBuiltTransportClient(settings)
				.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("127.0.0.1"), 9300));
		BulkRequestBuilder bulk = client.prepareBulk();

		ObjectMapper objmapper = new ObjectMapper();
		objmapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

		String[] header;
		String[] strarr;
		int i = 0;
		int j = 0, k = 0, count = 0;
		JSONObject object = new JSONObject();
		header = reader.readNext();
		for (i = 0; i < header.length - 1; i++)
			System.out.print(header[i] + " ");
		System.out.println();
		System.out.println("header length is:::::::::::::::::" + header.length);
		JSONArray jarray = new JSONArray();

		while ((strarr = reader.readNext()) != null) {
			for (int b = 0; b < strarr.length - 1; b++) {
				System.out.println(header[b] + "====>" + strarr[b]);
			}
			System.out.println("Strarr length is:::::::::::" + strarr.length);
			for (j = 0; j < strarr.length - 1; j++) {
				System.out.println(header[j] + "=====================================>" + strarr[j]);
				
					Float data = null;
					int scores=0;
					if(header[j].equals("P_PriceStr"))
					{
						try{
							if(strarr[j].equals("N/A"))
							{
								data=0.0f;
							}
							else
							data=Float.parseFloat(strarr[j]);
						}
						catch(NumberFormatException e)
						{
							System.out.println("Exception occured"+e.getCause());
							
						}
						finally
						{
							object.put(header[j], data);
						}
					}
					else if(header[j].equals("P_Score"))
					{
						try{
							scores=Integer.parseInt(strarr[j]);
						}
						catch(NumberFormatException e)
						{
							System.out.println("Exception occured"+e.getCause());
							
						}
						finally
						{
							object.put(header[j], scores);
						}
					}
				
				

				
				else if (j == strarr.length - 2) {
					System.out.println("entered else if:::::::::::::::::::::");
					if (!strarr[j].isEmpty()) {
						object.put(header[j], strarr[j]);
					}

				} else if (header[j].equals(header[j + 1])) {
					System.out.println("entered if::::::::::::::::::::::::::::::::;");
					jarray = new JSONArray();
					for (k = j + 1; k < strarr.length - 1; k++) {
						if (header[j].equals(header[k])) {
							count = 0;
							if (!strarr[k - 1].equals("")) {
								System.out
										.println(header[j] + "=====================================>" + strarr[k - 1]);
								jarray.add(strarr[k - 1]);
							}
							count += 1;
						} else {
							break;
						}
					}
					if (count == 1) {
						if (!strarr[k - 1].equals(""))
							jarray.add(strarr[k - 1]);
						System.out.println("jarray is::::::::::::::::::::::::::::::::" + jarray.toString());
						object.put(header[j], jarray);
						System.out.println();
						System.out.println("entered");
						j = k - 1;
					}

				} else {
					System.out.println("entered else:::::::::::::::");
					object.put(header[j], strarr[j]);
				}
			}
			strarr = null;
			System.out.println(object);
			String dataofjson = object.toString();
			Map<String, Object> map = objmapper.readValue(dataofjson, new TypeReference<Map<String, Object>>() {

			});
			bulk.add(client.prepareIndex("wines", "mapwine").setSource(map));
			map.clear();
		}
		BulkResponse bulkresponse = bulk.get();
		System.out.println("Successfully completed indexing..................!");
		if (bulkresponse.hasFailures())
			System.out.println("encountered failures");
		client.close();

	}
	

}
