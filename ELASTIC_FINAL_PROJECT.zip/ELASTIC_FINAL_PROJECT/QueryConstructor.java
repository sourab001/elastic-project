package com.mindtree.winery.QueryBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.web.servlet.ModelAndView;

public class QueryConstructor {

	public static void paginationquery(QueryBuilder qb, ModelAndView mav, TransportClient client,
			AggregationBuilder aggregationwinery, AggregationBuilder aggregationwinetype1,
			AggregationBuilder aggregationwinetype2, AggregationBuilder aggregationflavour,
			AggregationBuilder aggregationregion, int page, String sortkey, String sortorder) {
		SearchResponse response = client.prepareSearch("wines").setTypes("mapwine").setQuery(qb)
				.setFrom((page - 1) * 10).setSize(10).addAggregation(aggregationwinery)
				.addAggregation(aggregationwinetype1).addAggregation(aggregationwinetype2)
				.addAggregation(aggregationflavour).addAggregation(aggregationregion).setExplain(false).execute()
				.actionGet();
		Terms aggrwinery = response.getAggregations().get("winery");
		Terms aggrwinetype1 = response.getAggregations().get("type1wine");
		Terms aggwinetype2 = response.getAggregations().get("type2wine");
		Terms aggflavour = response.getAggregations().get("flavour");
		Terms aggregion = response.getAggregations().get("region");

		Map<String, Integer> aggmapwinery = new HashMap<>();
		Map<String, Integer> aggmapwinetype1 = new HashMap<>();
		Map<String, Integer> aggmapwinetype2 = new HashMap<>();
		Map<String, Integer> aggmapflavour = new HashMap<>();
		Map<String, Integer> aggmapregion = new HashMap<>();
		for (Terms.Bucket entry : aggrwinery.getBuckets()) {
			aggmapwinery.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggrwinetype1.getBuckets()) {
			aggmapwinetype1.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggwinetype2.getBuckets()) {
			aggmapwinetype2.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggflavour.getBuckets()) {
			aggmapflavour.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggregion.getBuckets()) {
			aggmapregion.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		System.out.println("aggmapwinery is::::::::::::::::" + aggmapwinery);
		System.out.println("aggmapwinetype1 is::::::::::::::::" + aggmapwinetype1);
		System.out.println("aggmapwinetype2 is::::::::::::::::" + aggmapwinetype2);
		System.out.println("aggmapflavour is::::::::::::::::" + aggmapflavour);
		System.out.println("aggmapregion is::::::::::::::::" + aggmapregion);

		SearchHit[] results = response.getHits().getHits();
		long count = response.getHits().getTotalHits();
		@SuppressWarnings("unused")
		int pagecount = (int) ((count + 10) / 10);
		System.out.println("total is:::::::::::::::::::::::::::::::::::::" + count);
		System.out.println("pagecount is::::::::::::::::::::::::::::::::::"+pagecount);
		Map<String, Object> resultmap = new HashMap<>();
		List<Map<String, Object>> finalresult = new ArrayList<>();
		System.out.println("Current results: " + results.length);
		for (SearchHit hit : results) {
			System.out.println("------------------------------");
			resultmap = hit.getSource();
			System.out.println(resultmap);
			finalresult.add(resultmap);
		}
		Map<String,String> maplocal=com.mindtree.winery.Controller.WineController.clickedbreads();

		mav.setViewName("app.jsp");
		mav.addObject("count", count);
		mav.addObject("details", finalresult);
		mav.addObject("aggmapwinery", aggmapwinery);
		mav.addObject("aggmapwinetype1", aggmapwinetype1);
		mav.addObject("aggmapwinetype2", aggmapwinetype2);
		mav.addObject("aggmapflavour", aggmapflavour);
		mav.addObject("aggmapregion", aggmapregion);
		mav.addObject("page", page);
		mav.addObject("pagecount", pagecount);
		mav.addObject("maplocal", maplocal);

	}

	public static void sortquery(QueryBuilder qb, ModelAndView mav, TransportClient client,
			AggregationBuilder aggregationwinery, AggregationBuilder aggregationwinetype1,
			AggregationBuilder aggregationwinetype2, AggregationBuilder aggregationflavour,
			AggregationBuilder aggregationregion, String sortkey, String sortorder,int page) {
		SortBuilder<?> sortbuilder = null;
		System.out.println("entered sort query builder:::::::::::::::::::::::");
		System.out.println("sortkey is::::::::::::::::::" + sortkey);
		System.out.println("sortorder is::::::::::::::::::" + sortorder);
		if (sortorder != null) {
			if (sortkey.equals("price") && sortorder.equals("ascending")) {
				System.out.println("entered if::::::::::::::::::");
				sortkey = "P_PriceStr";
				sortbuilder = SortBuilders.fieldSort(sortkey).order(SortOrder.ASC);

			} else if (sortkey.equals("price") && sortorder.equals("descending")) {
				System.out.println("entered else if 1::::::::::::::::::");
				sortkey = "P_PriceStr";
				sortbuilder = SortBuilders.fieldSort(sortkey).order(SortOrder.DESC);
			} else if (sortkey.equals("score") && sortorder.equals("ascending")) {
				System.out.println("entered else if 2::::::::::::::::::");
				sortkey = "P_Score";
				sortbuilder = SortBuilders.fieldSort(sortkey).order(SortOrder.ASC);

			} else if (sortkey.equals("score") && sortorder.equals("descending")) {
				System.out.println("entered else if 3::::::::::::::::::");
				sortkey = "P_Score";
				sortbuilder = SortBuilders.fieldSort(sortkey).order(SortOrder.DESC);
			} else if (sortorder.equals("ascending")) {
				System.out.println("entered else if 4::::::::::::::::::");
				sortkey = "P_Score";
				sortbuilder = SortBuilders.fieldSort(sortkey).order(SortOrder.ASC);
			} else {
				System.out.println("entered else::::::::::::::::::");
				sortkey = "P_Score";
				sortbuilder = SortBuilders.fieldSort(sortkey).order(SortOrder.DESC);
			}
		}

		else {
			if (sortkey.equals("price")) {
				sortkey = "P_PriceStr";
				sortbuilder = SortBuilders.fieldSort(sortkey).order(SortOrder.DESC);
			} else if (sortkey.equals("score")) {
				sortkey = "P_Score";
				sortbuilder = SortBuilders.fieldSort(sortkey).order(SortOrder.DESC);
			}
		}

		SearchResponse response = client.prepareSearch("wines").setTypes("mapwine").setQuery(qb).addSort(sortbuilder)
				.addAggregation(aggregationwinery).addAggregation(aggregationwinetype1)
				.addAggregation(aggregationwinetype2).addAggregation(aggregationflavour)
				.addAggregation(aggregationregion).setExplain(false).execute().actionGet();
		Terms aggrwinery = response.getAggregations().get("winery");
		Terms aggrwinetype1 = response.getAggregations().get("type1wine");
		Terms aggwinetype2 = response.getAggregations().get("type2wine");
		Terms aggflavour = response.getAggregations().get("flavour");
		Terms aggregion = response.getAggregations().get("region");

		Map<String, Integer> aggmapwinery = new HashMap<>();
		Map<String, Integer> aggmapwinetype1 = new HashMap<>();
		Map<String, Integer> aggmapwinetype2 = new HashMap<>();
		Map<String, Integer> aggmapflavour = new HashMap<>();
		Map<String, Integer> aggmapregion = new HashMap<>();

		for (Terms.Bucket entry : aggrwinery.getBuckets()) {
			aggmapwinery.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggrwinetype1.getBuckets()) {
			aggmapwinetype1.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggwinetype2.getBuckets()) {
			aggmapwinetype2.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggflavour.getBuckets()) {
			aggmapflavour.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggregion.getBuckets()) {
			aggmapregion.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		System.out.println("aggmapwinery is::::::::::::::::" + aggmapwinery);
		System.out.println("aggmapwinetype1 is::::::::::::::::" + aggmapwinetype1);
		System.out.println("aggmapwinetype2 is::::::::::::::::" + aggmapwinetype2);
		System.out.println("aggmapflavour is::::::::::::::::" + aggmapflavour);
		System.out.println("aggmapregion is::::::::::::::::" + aggmapregion);

		SearchHit[] results = response.getHits().getHits();
		long count = response.getHits().getTotalHits();
		@SuppressWarnings("unused")
		int pagecount = (int) ((count + 10) / 10);
		System.out.println("total is:::::::::::::::::::::::::::::::::::::" + count);
		System.out.println("pagecount is::::::::::::::::::::::::::::::::::"+pagecount);
		Map<String, Object> resultmap = new HashMap<>();
		List<Map<String, Object>> finalresult = new ArrayList<>();
		System.out.println("Current results: " + results.length);
		for (SearchHit hit : results) {
			System.out.println("------------------------------");
			resultmap = hit.getSource();
			System.out.println(resultmap);
			finalresult.add(resultmap);
		}
		
		Map<String,String> maplocal=com.mindtree.winery.Controller.WineController.clickedbreads();
		
		mav.setViewName("app.jsp");
		mav.addObject("count", count);
		mav.addObject("details", finalresult);
		mav.addObject("aggmapwinery", aggmapwinery);
		mav.addObject("aggmapwinetype1", aggmapwinetype1);
		mav.addObject("aggmapwinetype2", aggmapwinetype2);
		mav.addObject("aggmapflavour", aggmapflavour);
		mav.addObject("aggmapregion", aggmapregion);
		mav.addObject("page", page);
		mav.addObject("pagecount", pagecount);
		mav.addObject("maplocal", maplocal);

	}

	public static void query(QueryBuilder qb, ModelAndView mav, TransportClient client,
			AggregationBuilder aggregationwinery, AggregationBuilder aggregationwinetype1,
			AggregationBuilder aggregationwinetype2, AggregationBuilder aggregationflavour,
			AggregationBuilder aggregationregion,int page) {
		SearchResponse response = client.prepareSearch("wines").setTypes("mapwine").setQuery(qb)
				.addAggregation(aggregationwinery).addAggregation(aggregationwinetype1)
				.addAggregation(aggregationwinetype2).addAggregation(aggregationflavour)
				.addAggregation(aggregationregion).setExplain(false).execute().actionGet();
		Terms aggrwinery = response.getAggregations().get("winery");
		Terms aggrwinetype1 = response.getAggregations().get("type1wine");
		Terms aggwinetype2 = response.getAggregations().get("type2wine");
		Terms aggflavour = response.getAggregations().get("flavour");
		Terms aggregion = response.getAggregations().get("region");

		Map<String, Integer> aggmapwinery = new HashMap<>();
		Map<String, Integer> aggmapwinetype1 = new HashMap<>();
		Map<String, Integer> aggmapwinetype2 = new HashMap<>();
		Map<String, Integer> aggmapflavour = new HashMap<>();
		Map<String, Integer> aggmapregion = new HashMap<>();
		List<Map<String, Integer>> ultimatelist=new ArrayList<>();
		for (Terms.Bucket entry : aggrwinery.getBuckets()) {
			aggmapwinery.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggrwinetype1.getBuckets()) {
			aggmapwinetype1.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggwinetype2.getBuckets()) {
			aggmapwinetype2.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggflavour.getBuckets()) {
			aggmapflavour.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		for (Terms.Bucket entry : aggregion.getBuckets()) {
			aggmapregion.put(entry.getKeyAsString(), (int) entry.getDocCount());
		}
		System.out.println("aggmapwinery is::::::::::::::::" + aggmapwinery);
		System.out.println("aggmapwinetype1 is::::::::::::::::" + aggmapwinetype1);
		System.out.println("aggmapwinetype2 is::::::::::::::::" + aggmapwinetype2);
		System.out.println("aggmapflavour is::::::::::::::::" + aggmapflavour);
		System.out.println("aggmapregion is::::::::::::::::" + aggmapregion);
		ultimatelist.add(aggmapwinery);
		ultimatelist.add(aggmapwinetype1);
		ultimatelist.add(aggmapwinetype2);
		ultimatelist.add(aggmapflavour);
		ultimatelist.add(aggmapregion);
//		com.mindtree.winery.Controller.WineController.returnlist(ultimatelist);
		SearchHit[] results = response.getHits().getHits();
		long count = response.getHits().getTotalHits();
		@SuppressWarnings("unused")
		int pagecount = (int) ((count + 10) / 10);
		System.out.println("total is:::::::::::::::::::::::::::::::::::::" + count);
		System.out.println("pagecount is::::::::::::::::::::::::::::::::::"+pagecount);
		Map<String, Object> resultmap = new HashMap<>();
		List<Map<String, Object>> finalresult = new ArrayList<>();
		System.out.println("Current results: " + results.length);
		for (SearchHit hit : results) {
			System.out.println("------------------------------");
			resultmap = hit.getSource();
			System.out.println(resultmap);
			finalresult.add(resultmap);
		}
		Map<String,String> maplocal=com.mindtree.winery.Controller.WineController.clickedbreads();
		
		System.out.println("NEW LOCAL MAP IS:::::::::::::::;"+maplocal);
		mav.setViewName("app.jsp");
		mav.addObject("count", count);
		mav.addObject("details", finalresult);
		mav.addObject("aggmapwinery", aggmapwinery);
		mav.addObject("aggmapwinetype1", aggmapwinetype1);
		mav.addObject("aggmapwinetype2", aggmapwinetype2);
		mav.addObject("aggmapflavour", aggmapflavour);
		mav.addObject("aggmapregion", aggmapregion);
		mav.addObject("page", page);
		mav.addObject("pagecount", pagecount);
		mav.addObject("maplocal", maplocal);

	}
	
	


}
