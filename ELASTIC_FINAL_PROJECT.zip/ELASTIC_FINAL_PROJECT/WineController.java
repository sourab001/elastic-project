package com.mindtree.winery.Controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.winery.QueryBuilder.QueryConstructor;



@RestController
public class WineController {

/*	@Value("${clustername}")
	 String clustername;

	@Value("${ipname}")
	String internetprotocolname;
	
	@Value("${tcpport}")
	 int tcpname;
	
*/
	
	
	String search;
	String winery;
	String winetype1;
	String winetype2;
	String flavour;
	String region;
	TransportClient client = null;
	String sortkey;
	int tempcounter = 0;
	QueryBuilder qb;
	String sortorder;
	int page = 1;
	static List<Map<String, Integer>> contlist = new ArrayList<>();
//	static Map<String, Map<String, Integer>> uniquemap = new HashMap<>();
	static LinkedHashSet<String> clicked = new LinkedHashSet<>();
//	static LinkedHashSet clickedagg = new LinkedHashSet<>();
	static Map<String, String> mapsglobal = new LinkedHashMap<>();
	List<String> listkeys = new ArrayList<>();
	List<String> listvalues = new ArrayList<>();
	static Map<String,Map<String, String>> mapsfinal=new LinkedHashMap<>();
	
	
	
	public WineController() throws UnknownHostException {
		 List<String> list=geturl();
		   int eport=Integer.parseInt(list.get(1));
		   Settings settings = Settings.builder().put("cluster.name", list.get(0)).build();
			client = new PreBuiltTransportClient(settings)
					.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(list.get(2)), eport));
	}
	
	
	static List<String> slist=new ArrayList<>();
	public static List<String> geturl() {

		String resourceName = "application.properties"; 
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		Properties props = new Properties();
		try (InputStream resourceStream = loader.getResourceAsStream(resourceName)) {
			props.load(resourceStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String clustername = props.getProperty("clustername");
		String elastictcpport = props.getProperty("tcpport");
		String iport = props.getProperty("ipname");
		slist.add(clustername);
		slist.add(elastictcpport);
		slist.add(iport);
		System.out.println(clustername+" "+elastictcpport+" "+iport);
		
		return slist;

	}
	
	

	
	
/*	@SuppressWarnings("resource")
	public WineController() throws UnknownHostException {
		Settings settings = Settings.builder().put("cluster.name", "my-application").build();
		client = new PreBuiltTransportClient(settings)
				.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("127.0.0.1"), 9300));
	}*/
	
/*	@SuppressWarnings("resource")
	public WineController() throws UnknownHostException {
		Settings settings = Settings.builder().put("cluster.name", clustername).build();
		client = new PreBuiltTransportClient(settings)
				.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(internetprotocolname), tcpname));
	}*/

	@RequestMapping("/breadcrumbs")
	public ModelAndView breadcrumbs(HttpServletRequest request) {
		System.out.println("entered bread crumbs:::::::::::::::::::::::::::::::::::::::::::");
		page=1;
		ModelAndView mv = new ModelAndView();
		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");
		String facet = request.getParameter("facet");
		String facetvalue = request.getParameter("facetvalue");
		System.out.println("FACET IS::::::::::::::::::::::::::" + facet);
		System.out.println("FACET VALUE IS:::::::::::::::::::::::" + facetvalue);
		Map<String, String> localsmap = new LinkedHashMap<>();
		localsmap.clear();
		tempcounter = 0;
		listkeys.clear();
		listvalues.clear();
		for (Entry<String, String> entry : mapsglobal.entrySet()) {
			if (!entry.getValue().equals(facetvalue)) {
				localsmap.put(entry.getKey(), entry.getValue());
				listkeys.add(entry.getKey());
				listvalues.add(entry.getValue());
				tempcounter += 1;
			} else {
				if (tempcounter == 0) {
					localsmap.put(entry.getKey(), entry.getValue());
					tempcounter = 1;
					listkeys.add(entry.getKey());
					listvalues.add(entry.getValue());
					break;
				} else
				{
					localsmap.put(entry.getKey(), entry.getValue());
					tempcounter += 1;
					listkeys.add(entry.getKey());
					listvalues.add(entry.getValue());

					break;
				}
					
			}
//			mapsglobal.clear();
//			mapsglobal=localsmap;
		}
		mapsglobal.clear();
		mapsfinal.clear();
		mapsglobal=localsmap;
		
		
/*		for(Entry<Map<String,String>, String> entry : mapsfinal.)
		{
			for(Entry<String,String> mapsfinal)
		}*/
		
		System.out.println("mapsglobal is:::::::::::::::::::::::::::" + mapsglobal);
		System.out.println("Locals map is::::::::::::::::::::::::::::"+localsmap);
		System.out.println("TEMPCOUNTER IS::::::::::::::::::::::::::" + tempcounter);
		System.out.println("LIST KEYS IS:::::::::::::::::::::::::::::");
		listkeys.forEach(System.out::println);
		System.out.println("LIST VALUES IS:::::::::::::::::::::::::::::");
		listvalues.forEach(System.out::println);

		if (tempcounter == 1) {
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
				System.out.println("List values is::::::::"+listvalues.get(0));
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
				System.out.println("List values is::::::::"+listvalues.get(0));
			}

		}

		else if (tempcounter == 2) {
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)))
						.must(QueryBuilders.matchQuery(listkeys.get(1), listvalues.get(1)))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
				System.out.println("List values is::::::::"+listvalues.get(0));
				System.out.println("List values is::::::::"+listvalues.get(1));
				System.out.println("List keys is::::::::"+listkeys.get(0));
				System.out.println("List keys is::::::::"+listkeys.get(1));
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)))
						.must(QueryBuilders.matchQuery(listkeys.get(1), listvalues.get(1)));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
				System.out.println("List values is::::::::"+listvalues.get(0));
				System.out.println("List values is::::::::"+listvalues.get(1));
				System.out.println("List keys is::::::::"+listkeys.get(0));
				System.out.println("List keys is::::::::"+listkeys.get(1));
				}
		}

		else if (tempcounter == 3) {
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)))
						.must(QueryBuilders.matchQuery(listkeys.get(1), listvalues.get(1)))
						.must(QueryBuilders.matchQuery(listkeys.get(2), listvalues.get(2)))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
				
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)))
						.must(QueryBuilders.matchQuery(listkeys.get(1), listvalues.get(1)))
						.must(QueryBuilders.matchQuery(listkeys.get(2), listvalues.get(2)));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (tempcounter == 4) {
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)))
						.must(QueryBuilders.matchQuery(listkeys.get(1), listvalues.get(1)))
						.must(QueryBuilders.matchQuery(listkeys.get(2), listvalues.get(2)))
						.must(QueryBuilders.matchQuery(listkeys.get(3), listvalues.get(3)))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)))
						.must(QueryBuilders.matchQuery(listkeys.get(1), listvalues.get(1)))
						.must(QueryBuilders.matchQuery(listkeys.get(2), listvalues.get(2)))
						.must(QueryBuilders.matchQuery(listkeys.get(3), listvalues.get(3)));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (tempcounter == 5) {
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)))
						.must(QueryBuilders.matchQuery(listkeys.get(1), listvalues.get(1)))
						.must(QueryBuilders.matchQuery(listkeys.get(2), listvalues.get(2)))
						.must(QueryBuilders.matchQuery(listkeys.get(3), listvalues.get(3)))
						.must(QueryBuilders.matchQuery(listkeys.get(4), listvalues.get(4)))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery(listkeys.get(0), listvalues.get(0)))
						.must(QueryBuilders.matchQuery(listkeys.get(1), listvalues.get(1)))
						.must(QueryBuilders.matchQuery(listkeys.get(2), listvalues.get(2)))
						.must(QueryBuilders.matchQuery(listkeys.get(3), listvalues.get(3)))
						.must(QueryBuilders.matchQuery(listkeys.get(4), listvalues.get(4)));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		return mv;

	}



	public static Map<String, String> clickedbreads() {
		System.out.println("MAPS GLOBAL IS:::::::::::::::::::::::::");
		System.out.println(mapsglobal);
		return mapsglobal;
	}

	@RequestMapping("/pagination")
	public ModelAndView pagination(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");
		String pagecounter = request.getParameter("pagecounter");
		if (pagecounter.equals("next"))
			page += 1;
		else
			page -= 1;
		QueryConstructor.paginationquery(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
				aggregationflavour, aggregationregion, page,sortkey,sortorder);
		return mv;

	}

	@RequestMapping("/sort")
	public ModelAndView sort(HttpServletRequest request) {
		System.out.println("entered sort");
		page = 1;
		ModelAndView mv = new ModelAndView();
		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");
		sortkey = request.getParameter("sortkey");
		sortorder = request.getParameter("sortorder");
		System.out.println("sortkey is::::::::::::::::::" + sortkey);
		System.out.println("sortorder is::::::::::::::::::" + sortorder);
		System.out.println(qb);
		QueryConstructor.sortquery(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
				aggregationflavour, aggregationregion, sortkey, sortorder, page);
		mv.addObject("sortkey", sortkey);
		return mv;
	}

	@RequestMapping("/")
	public ModelAndView LandingPage(HttpServletRequest request) throws UnknownHostException {
		System.out.println("entered");
		search = null;
		winery = null;
		winetype1 = null;
		winetype2 = null;
		flavour = null;
		region = null;
		page = 1;
		clicked.clear();
		mapsglobal.clear();
		listkeys.clear();
		listvalues.clear();
		ModelAndView mv = new ModelAndView();
		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");

		qb = QueryBuilders.matchAllQuery();
		System.out.println(qb);
//		System.out.println(qb+" ");
		QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
				aggregationflavour, aggregationregion, page);

		System.out.println("------------------------------------------------------");
		System.out.println("THE ULTIMATE LIST IS:::::::::::::::::::::::");
		contlist.forEach(System.out::println);

		return mv;
	}

	@RequestMapping("/winery")
	public ModelAndView winery(HttpServletRequest request) {
		System.out.println("entered");
		page = 1;
		ModelAndView mv = new ModelAndView();
		winery = request.getParameter("winery");
		clicked.add(winery);
		mapsglobal.put("P_Winery.keyword", winery);
		mapsfinal.put("winery",mapsglobal);
		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");

		if (winetype1 != null && winetype2 != null && flavour != null && region != null) {
			System.out.println("entered if:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && winetype2 != null && flavour != null) {
			System.out.println("entered else if 1:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && winetype2 != null && region != null) {
			System.out.println("entered else if 2:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && flavour != null && region != null) {
			System.out.println("entered else if 3:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null && flavour != null && region != null) {
			System.out.println("entered else if 4:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && winetype2 != null) {
			System.out.println("entered else if 5:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && flavour != null) {
			System.out.println("entered else if 6:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && region != null) {
			System.out.println("entered else if 7:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null && flavour != null) {
			System.out.println("entered else if 8:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null && region != null) {
			System.out.println("entered else if 9:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (flavour != null && region != null) {
			System.out.println("entered else if 10:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null) {
			System.out.println("entered else if 11:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null) {
			System.out.println("entered else if 12:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (flavour != null) {
			System.out.println("entered else if 13:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (region != null) {
			System.out.println("entered else if 14:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else {
			System.out.println("entered else:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		mv.addObject("winery", winery);
		mv.addObject("winetype1", winetype1);
		return mv;

	}

	@RequestMapping("/winetype1")
	public ModelAndView winetype1(HttpServletRequest request) {
		System.out.println("entered winetype1::::::::::::::::::::::::::::::::");
		page = 1;
		ModelAndView mv = new ModelAndView();
		winetype1 = request.getParameter("winetype1");
		clicked.add(winetype1);
		mapsglobal.put("P_WineType1.keyword", winetype1);
		mapsfinal.put("winetype1",mapsglobal);
		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");

		if (winery != null && winetype2 != null && flavour != null && region != null) {
			System.out.println("entered if:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype2 != null && flavour != null) {
			System.out.println("entered else if 1:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype2 != null && region != null) {
			System.out.println("entered if 2:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && flavour != null && region != null) {
			System.out.println("entered if 3:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null && flavour != null && region != null) {
			System.out.println("entered else if 4:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype2 != null) {
			System.out.println("entered else if 5:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && flavour != null) {
			System.out.println("entered else if 6:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && region != null) {
			System.out.println("entered else if 7:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null && flavour != null) {
			System.out.println("entered else if 8:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null && region != null) {
			System.out.println("entered else if 9:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (flavour != null && region != null) {
			System.out.println("entered else if 10:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null) {
			System.out.println("entered else if 11:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null) {
			System.out.println("entered else if 12:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (flavour != null) {
			System.out.println("entered else if 13:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (region != null) {
			System.out.println("entered else if 14:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else {
			System.out.println("entered else:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}
		mv.addObject("winery", winery);
		mv.addObject("winetype1", winetype1);
		return mv;
	}

	@RequestMapping("/winetype2")
	public ModelAndView winetype2(HttpServletRequest request) {
		System.out.println("entered winetype2::::::::::::::::::::::::::::::::");
		page = 1;
		ModelAndView mv = new ModelAndView();
		winetype2 = request.getParameter("winetype2");
		clicked.add(winetype2);
		mapsglobal.put("P_WineType2.keyword", winetype2);
		System.out.println("winetype2 is:::::::::::::::::::::" + winetype2);

		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");

		if (winery != null && winetype1 != null && flavour != null && region != null) {
			System.out.println("entered if:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype1 != null && flavour != null) {
			System.out.println("entered else if 1:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype1 != null && region != null) {
			System.out.println("entered else if 2:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && flavour != null && region != null) {
			System.out.println("entered else if 3:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && flavour != null && region != null) {
			System.out.println("entered else if 4:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype1 != null) {
			System.out.println("entered else if 5:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && flavour != null) {
			System.out.println("entered else if 6:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && region != null) {
			System.out.println("entered esle if 7:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && flavour != null) {
			System.out.println("entered else if 8:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && region != null) {
			System.out.println("entered else if 9:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (flavour != null && region != null) {
			System.out.println("entered else if 10:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null) {
			System.out.println("entered else if 11:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null) {
			System.out.println("entered else if 12:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (flavour != null) {
			System.out.println("entered else if 13:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (region != null) {
			System.out.println("entered else if 14:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else {
			System.out.println("entered else:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}
		return mv;
	}

	@RequestMapping("/flavour")
	public ModelAndView flavour(HttpServletRequest request) {
		System.out.println("entered flavour::::::::::::::::::::::::::::::::");
		page = 1;
		ModelAndView mv = new ModelAndView();
		flavour = request.getParameter("flavour");
		clicked.add(flavour);
		mapsglobal.put("P_Flavors.keyword", flavour);
		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");

		if (winery != null && winetype1 != null && winetype2 != null && region != null) {
			System.out.println("entered if:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype1 != null && winetype2 != null) {
			System.out.println("entered else if 1:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype1 != null && region != null) {
			System.out.println("entered else if 2:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype2 != null && region != null) {
			System.out.println("entered else if 3:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && winetype2 != null && region != null) {
			System.out.println("entered else if 4:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype1 != null) {
			System.out.println("entered else if 5:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype2 != null) {
			System.out.println("entered else if 6:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && region != null) {
			System.out.println("entered else if 7:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && winetype2 != null) {
			System.out.println("entered else if 8:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && region != null) {
			System.out.println("entered else if 9:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null && region != null) {
			System.out.println("entered else if 10:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null) {
			System.out.println("entered else if 11:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null) {
			System.out.println("entered else if 12:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null) {
			System.out.println("entered else if 13:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (region != null) {
			System.out.println("entered else if 14:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else {
			System.out.println("entered else:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}
		return mv;
	}

	@RequestMapping("/region")
	public ModelAndView region(HttpServletRequest request) {
		System.out.println("entered region::::::::::::::::::::::::::::::::");
		page = 1;
		ModelAndView mv = new ModelAndView();
		region = request.getParameter("region");
		clicked.add(region);
		mapsglobal.put("P_Region.keyword", region);
		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");

		if (winery != null && winetype1 != null && winetype2 != null && flavour != null) {
			System.out.println("entered if:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype1 != null && winetype2 != null) {
			System.out.println("entered else if 1:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype1 != null && flavour != null) {
			System.out.println("entered else if 2:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype2 != null && flavour != null) {
			System.out.println("entered else if 3:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && winetype2 != null && flavour != null) {
			System.out.println("entered else if 4:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype1 != null) {
			System.out.println("entered else if 5:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && winetype2 != null) {
			System.out.println("entered else if 6:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null && flavour != null) {
			System.out.println("entered else if 7:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && winetype2 != null) {
			System.out.println("entered else if 8:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null && flavour != null) {
			System.out.println("entered else if 9:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null && flavour != null) {
			System.out.println("entered else if 10:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winery != null) {
			System.out.println("entered else if 11:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Winery.keyword", winery))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype1 != null) {
			System.out.println("entered else if 12:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType1.keyword", winetype1))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (winetype2 != null) {
			System.out.println("entered else if 13:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_WineType2.keyword", winetype2))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else if (flavour != null) {
			System.out.println("entered else if 14:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Flavors.keyword", flavour))
						.must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}

		else {
			System.out.println("entered else:::::::::::::::::::::::::::::::::::");
			if (search != null) {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Region.keyword", region))
						.must(QueryBuilders.matchQuery("_all", search));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			} else {
				qb = QueryBuilders.boolQuery().must(QueryBuilders.matchQuery("P_Region.keyword", region));
				System.out.println(qb);
				QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
						aggregationflavour, aggregationregion, page);
			}
		}
		return mv;

	}

	@RequestMapping("/results")
	public ModelAndView getResults(HttpServletRequest request) {
		System.out.println("entered");
		mapsglobal.clear();
		clicked.clear();
		search = null;
		winery = null;
		winetype1 = null;
		winetype2 = null;
		flavour = null;
		region = null;
		page = 1;
		ModelAndView mv = new ModelAndView();
		search = request.getParameter("search");
		AggregationBuilder aggregationwinery = AggregationBuilders.terms("winery").field("P_Winery.keyword");
		AggregationBuilder aggregationwinetype1 = AggregationBuilders.terms("type1wine").field("P_WineType1.keyword");
		AggregationBuilder aggregationwinetype2 = AggregationBuilders.terms("type2wine").field("P_WineType2.keyword");
		AggregationBuilder aggregationflavour = AggregationBuilders.terms("flavour").field("P_Flavors.keyword");
		AggregationBuilder aggregationregion = AggregationBuilders.terms("region").field("P_Region.keyword");
		if (search.equals("")) {
			System.out.println("search is:::::::::::::::::::::::" + search);
			search = null;
			qb = QueryBuilders.matchAllQuery();
			System.out.println(qb);
			QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
					aggregationflavour, aggregationregion, page);
		} else {
			System.out.println("search is:::::::::::::::::::::::" + search);
			qb = QueryBuilders.matchQuery("_all", search);
			System.out.println(qb);
			QueryConstructor.query(qb, mv, client, aggregationwinery, aggregationwinetype1, aggregationwinetype2,
					aggregationflavour, aggregationregion, page);
		}
		return mv;

	}

}
